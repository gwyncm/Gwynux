#!/bin/sh
autoheader
autoconf
