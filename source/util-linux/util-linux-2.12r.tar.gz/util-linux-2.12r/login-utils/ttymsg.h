char *ttymsg(struct iovec *iov, int iovcnt, char *line, int tmout);

