extern int carefulputc(int c, FILE *fp);
