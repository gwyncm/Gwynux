#define VERSION 3.80
#define VERSION_STR "3.80"
#define VERSION_MAJOR 3
#define VERSION_MINOR 80
#define YEAR 2009
#define YEAR_STR "2009"
