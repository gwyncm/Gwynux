#define TYPE uint8_t
#define BWL(x) x ## b
#define BIOSCALL 0xb10b
#include "pci/writex.c"
