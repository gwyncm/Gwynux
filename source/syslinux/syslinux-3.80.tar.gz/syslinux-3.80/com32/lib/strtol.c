#define TYPE signed long
#define NAME strtol
#include "strtox.c"
