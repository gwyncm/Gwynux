#define TYPE signed long long
#define NAME strtoll
#include "strtox.c"
