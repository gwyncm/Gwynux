#include <stdlib.h>

/* Default stack size 8 MB */
size_t __stack_size = 8 << 20;
