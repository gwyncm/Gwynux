#ifndef _TIME_H
#define _TIME_H

/* empty */

#endif
