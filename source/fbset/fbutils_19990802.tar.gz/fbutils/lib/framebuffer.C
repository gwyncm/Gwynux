
#include <errno.h>
#include <fcntl.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/ioctl.h>

#include "database.h"
#include "framebuffer.h"
#include "util.h"


    //  Generic Frame Buffer Device Operations

FrameBuffer::FrameBuffer(const char *name, bool read_write)
{
    if ((fd = open(name, read_write ? O_RDWR : O_RDONLY)) < 0)
	Die("Cannot open %s: %s\n", name, strerror(errno));
}

FrameBuffer::~FrameBuffer()
{
    close(fd);
}

int FrameBuffer::Ioctl(unsigned long request, void *p) const
{
    return ioctl(fd, request, p);
}

void FixScreenInfo::Get(const FrameBuffer &fb)
{
    fb_fix_screeninfo *fix = this;
    if (fb.Ioctl(FBIOGET_FSCREENINFO, fix))
	Die("ioctl FBIOGET_FSCREENINFO: %s\n", strerror(errno));
}

VarScreenInfo::VarScreenInfo()
{
    memset(this, 0, sizeof(*this));
}

VarScreenInfo::VarScreenInfo(const Videomode &mode)
{
    memset(this, 0, sizeof(*this));

    xres = mode.xres;
    yres = mode.yres;
    pixclock = mode.pixclock;
    left_margin = mode.left_margin;
    right_margin = mode.right_margin;
    upper_margin = mode.upper_margin;
    lower_margin = mode.lower_margin;
    hsync_len = mode.hsync_len;
    vsync_len = mode.vsync_len;
    vmode = mode.vmode;
    sync = mode.sync;

    bits_per_pixel = mode.bits_per_pixel;
    grayscale = mode.grayscale;
    red = mode.red;
    green = mode.green;
    blue = mode.blue;
    transp = mode.transp;
    nonstd = mode.nonstd;

    xres_virtual = mode.xres_virtual;
    yres_virtual = mode.yres_virtual;

    accel_flags = mode.accel_flags;
}

void VarScreenInfo::Get(const FrameBuffer &fb)
{
    fb_var_screeninfo *var = this;
    if (fb.Ioctl(FBIOGET_VSCREENINFO, var))
	Die("ioctl FBIOGET_VSCREENINFO: %s\n", strerror(errno));
}

void VarScreenInfo::Set(const FrameBuffer &fb, bool all)
{
    activate &= ~FB_ACTIVATE_TEST;
    if (all)
	activate |= FB_ACTIVATE_ALL;
    fb_var_screeninfo *var = this;
    if (fb.Ioctl(FBIOPUT_VSCREENINFO, var))
	Die("ioctl FBIOPUT_VSCREENINFO: %s\n", strerror(errno));
}

bool VarScreenInfo::Try(const FrameBuffer &fb)
{
    bool res = true;

    activate |= FB_ACTIVATE_TEST;
    activate &= ~FB_ACTIVATE_ALL;
    fb_var_screeninfo *var = this;
    if (fb.Ioctl(FBIOPUT_VSCREENINFO, var))
	res = false;
    return res;
}

void VarScreenInfo::Print(const char *indent) const
{
    Geometry geometry(*this);
    geometry.Print(indent);
    Format format(*this);
    format.Print(indent);
    Virtual virtual_(*this);
    virtual_.Print(indent);
    printf("%sactivate = %d\n", indent, activate);
    printf("%sheight = %d\n", indent, height);
    printf("%swidth = %d\n", indent, width);
    printf("%saccel_flags = %d\n", indent, accel_flags);
}

void VarScreenInfo::XFree86(const char *indent) const
{
    Geometry geometry(*this);
    geometry.XFree86(indent);
}

ColorMap::ColorMap(u_int len_, u_int start_, bool transp_)
{
    start = start_;
    len = len_;
    red = new __u16[len];
    green = new __u16[len];
    blue = new __u16[len];
    transp = transp_ ? new __u16[len] : NULL;
}

ColorMap::~ColorMap()
{
    delete [] red;
    delete [] green;
    delete [] blue;
    delete [] transp;
}

void ColorMap::Get(const FrameBuffer &fb)
{
    fb_cmap *cmap = this;
    if (fb.Ioctl(FBIOGETCMAP, cmap))
	Die("ioctl FBIOGETCMAP: %s\n", strerror(errno));
}

void ColorMap::Set(const FrameBuffer &fb) const
{
    fb_cmap *cmap = (fb_cmap *)this;
    if (fb.Ioctl(FBIOPUTCMAP, cmap))
	Die("ioctl FBIOPUTCMAP: %s\n", strerror(errno));
}

void ColorMap::Invert(void) const
{
    for (u_int i = 0; i < len; i++) {
	red[i] ^= 0xffff;
	green[i] ^= 0xffff;
	blue[i] ^= 0xffff;
	if (transp)
	    transp[i] ^= 0xffff;
    }
}

void ColorMap::Print(const char *indent = "") const
{
    printf("start = %d\n", start);
    printf("len = %d\n", len);
    for (u_int i = 0; i < len; i++) {
	printf("%s%03x: %04x %04x %04x", indent, i, red[i], green[i], blue[i]);
	if (transp)
	    printf(" %04x\n", transp[i]);
	else
	    putchar('\n');
    }
}

void Con2FBMap::Get(const FrameBuffer &fb)
{
    fb_con2fbmap *map = this;
    if (fb.Ioctl(FBIOGET_CON2FBMAP, map))
	Die("ioctl FBIOGET_CON2FBMAP: %s\n", strerror(errno));
}

void Con2FBMap::Set(const FrameBuffer &fb) const
{
    fb_con2fbmap *map = (fb_con2fbmap *)this;
    if (fb.Ioctl(FBIOPUT_CON2FBMAP, map))
	Die("ioctl FBIOPUT_CON2FBMAP: %s\n", strerror(errno));
}

void Con2FBMap::Print(const char *indent = "") const
{
    printf("%sconsole %d -> fb %d\n", indent, console, framebuffer);
}


    //  Hardware Text Modes

struct mapentry {
    __u32 id;
    const char *name;
};

static const struct mapentry Textmodes[] = {
#define DEF(id, name)	{ FB_AUX_TEXT_##id, name },
    DEF(MDA, "Monochrome text")
    DEF(CGA, "CGA/EGA/VGA Color text")
    DEF(S3_MMIO, "S3 MMIO fasttext")
    DEF(MGA_STEP16, "MGA Millennium I step 16 text")
    DEF(MGA_STEP8, "MGA step 8 text")
#undef DEF
    // last entry has name == NULL
    { 0,                      NULL }
};


static const struct mapentry VGAModes[] = {
#define DEF(id, name)	{ FB_AUX_VGA_PLANES_##id, name },
    DEF(VGA4, "VGA 16 colors in 4 planes")
    DEF(CFB4, "VGA 16 colors in 1 plane")
    DEF(CFB8, "VGA 256 colors in 4 planes")
#undef DEF
    // last entry has name == NULL
    { 0,                      NULL }
};


    //  Visuals

static const struct mapentry Visuals[] = {
#define DEF(id, name)	{ FB_VISUAL_##id, name },
    DEF(MONO01, "MONO01")
    DEF(MONO10, "MONO10")
    DEF(TRUECOLOR, "TRUECOLOR")
    DEF(PSEUDOCOLOR, "PSEUDOCOLOR")
    DEF(DIRECTCOLOR, "DIRECTCOLOR")
    DEF(STATIC_PSEUDOCOLOR, "STATIC PSEUDOCOLOR")
#undef DEF
    // last entry has name == NULL
    { 0,                      NULL }
};


    //  Hardware Accelerators

static const struct mapentry Accelerators[] = {
#define DEF(id, name)	{ FB_ACCEL_##id, name },
    DEF(NONE, "No")
    DEF(ATARIBLITT, "Atari Blitter")
    DEF(AMIGABLITT, "Amiga Blitter")
    DEF(S3_TRIO64, "S3 Trio64")
    DEF(NCR_77C32BLT, "NCR 77C32BLT")
    DEF(S3_VIRGE, "S3 ViRGE")
    DEF(ATI_MACH64GX, "ATI Mach64GX")
    DEF(DEC_TGA, "DEC 21030 TGA")
    DEF(ATI_MACH64CT, "ATI Mach64CT")
    DEF(ATI_MACH64VT, "ATI Mach64VT")
    DEF(ATI_MACH64GT, "ATI Mach64GT")
    DEF(SUN_CREATOR, "Sun Creator/Creator3D")
    DEF(SUN_CGSIX, "Sun cg6")
    DEF(SUN_LEO, "Sun leo/zx")
    DEF(IMS_TWINTURBO, "IMS Twin Turbo")
    DEF(3DLABS_PERMEDIA2, "3Dlabs Permedia 2")
    DEF(MATROX_MGA2064W, "Matrox MGA2064W (Millennium)")
    DEF(MATROX_MGA1064SG, "Matrox MGA1064SG (Mystique)")
    DEF(MATROX_MGA2164W, "Matrox MGA2164W (Millennium II)")
    DEF(MATROX_MGA2164W_AGP, "Matrox MGA2164W (Millennium II AGP)")
    DEF(MATROX_MGAG100, "Matrox G100 (Productiva G100)")
    DEF(MATROX_MGAG200, "Matrox G200 (Millennium, Mystique)")
    DEF(SUN_CG14, "Sun cg14")
    DEF(SUN_BWTWO, "Sun bw2")
    DEF(SUN_CGTHREE, "Sun cg3")
    DEF(SUN_TCX, "Sun tcx")
    DEF(MATROX_MGAG400, "Matrox G400")
    DEF(NV3, "nVidia RIVA 128")
    DEF(NV4, "nVidia RIVA TNT")
    DEF(NV5, "nVidia RIVA TNT2")
#undef DEF
    // last entry has name == NULL
    { 0,                      NULL }
};


    //  Display the Frame Buffer Device Information

static void Identify(const struct mapentry *map, __u32 id, const char *type)
{
    const struct mapentry *t;

    for (t = map; t->name; t++)
	if (id == t->id)
	    break;
    if (t->name)
	puts(t->name);
    else
	printf("Unknown %s (%d)\n", type, id);
}

void FixScreenInfo::Print(const char *indent) const
{
    printf("%sFrame buffer device information:\n", indent);
    printf("%s    Name        : %s\n", indent, id);
    printf("%s    Address     : %p\n", indent, smem_start);
    printf("%s    Size        : %d\n", indent, smem_len);
    printf("%s    Type        : ", indent);
    switch (type) {
	case FB_TYPE_PACKED_PIXELS:
	    puts("PACKED PIXELS");
	    break;
	case FB_TYPE_PLANES:
	    puts("PLANES");
	    break;
	case FB_TYPE_INTERLEAVED_PLANES:
	    printf("INTERLEAVED PLANES (%d bytes interleave)\n", type_aux);
	    break;
	case FB_TYPE_TEXT:
	    Identify(Textmodes, type_aux, "text mode");
	    break;
	case FB_TYPE_VGA_PLANES:
	    Identify(VGAModes, type_aux, "VGA mode");
	    break;
	default:
	    printf("Unknown type (%d)\n", type);
	    printf("%s    Type_aux    : %d\n", indent, type_aux);
	    break;
    }
    printf("%s    Visual      : ", indent);
    Identify(Visuals, visual, "visual");
    printf("%s    XPanStep    : %d\n", indent, xpanstep);
    printf("%s    YPanStep    : %d\n", indent, ypanstep);
    printf("%s    YWrapStep   : %d\n", indent, ywrapstep);
    printf("%s    LineLength  : %d\n", indent, line_length);
    if (mmio_len) {
	printf("%s    MMIO Address: %p\n", indent, mmio_start);
	printf("%s    MMIO Size   : %d\n", indent, mmio_len);
    }
    printf("%s    Accelerator : ", indent);
    Identify(Accelerators, accel, "accelerator");
}
