
#include "list.h"
#include "util.h"


    //  List Node

Node::Node(const char *name)
    : Succ(NULL), Pred(NULL), Name(NULL)
{
    if (name) {
	Name = new char[strlen(name)+1];
	strcpy(Name, name);
    }
}

Node::~Node()
{
    assert(Succ == NULL);
    assert(Pred == NULL);
    delete Name;
}

void Node::Insert(Node *pred)
{
    assert(Succ == NULL);
    assert(Pred == NULL);
    assert(pred != NULL);
    assert(pred->Succ != NULL);
    assert(pred->Pred != NULL);
    Succ = pred->Succ;
    Pred = pred;
    Succ->Pred = this;
    pred->Succ = this;
}

void Node::Remove(void)
{
    assert(Succ != NULL);
    assert(Pred != NULL);
    Pred->Succ = Succ;
    Succ->Pred = Pred;
    Succ = NULL;
    Pred = NULL;
}

void Node::Dump(bool in_list) const
{
    printf("%s%s\n", in_list ? "    " : "node ", Name ? Name : "UNNAMED");
}


    //	List Header

List::List(const char *name)
{
    Head.Succ = &Tail;
    Tail.Pred = &Head;
    Name = new char[strlen(name)+1];
    strcpy(Name, name);
}

List::~List()
{
    Node *node;

    while ((node = RemHead()))
	delete node;

    assert(Head.Succ == &Tail);
    assert(Head.Pred == NULL);
    assert(Tail.Succ == NULL);
    assert(Tail.Pred == &Head);
    Head.Succ = NULL;
    Tail.Pred = NULL;
}

void List::AddHead(Node *node)
{
    assert(node != NULL);
    assert(node->Succ == NULL);
    assert(node->Pred == NULL);
    node->Succ = Head.Succ;
    node->Pred = &Head;
    Head.Succ->Pred = node;
    Head.Succ = node;
}

void List::AddTail(Node *node)
{
    assert(node != NULL);
    assert(node->Succ == NULL);
    assert(node->Pred == NULL);
    node->Succ = &Tail;
    node->Pred = Tail.Pred;
    Tail.Pred->Succ = node;
    Tail.Pred = node;
}

Node *List::RemHead(void)
{
    Node *node = Head.Succ->Succ;
    if (node) {
	node->Pred = &Head;
	node = Head.Succ;
	Head.Succ = node->Succ;
	node->Succ = NULL;
	node->Pred = NULL;
    }
    return node;
}

Node *List::RemTail(void)
{
    Node *node = Tail.Pred->Pred;
    if (node) {
	node->Succ = &Tail;
	node = Tail.Pred;
	Tail.Pred = node->Pred;
	node->Succ = NULL;
	node->Pred = NULL;
    }
    return node;
}

void List::Add(Node *node)
{
    if (node->Name) {
	Node *node2 = Find(node->Name, false);
	if (node2) {
	    Warn("Warning: redefinition of `%s' in list of \n", node->Name,
		 Name);
	    node2->Remove();
	    delete node2;
	}
    }
    AddTail(node);
}

Node *List::Find(const char *name, bool use_aliases) const
{
    Node *node;

    for (node = GetHead(); node; node = node->GetNext())
	if (!strcmp(node->Name, name))
	    break;
    if (!node && use_aliases) {
	const AliasNode *alias = Aliases.Find(name);
	if (alias)
	    node = Find(alias->GetAlias(), false);
    }
    return node;
}


void List::Dump(void) const
{
    printf("%s {\n", Name ? Name : "UNNAMED");
    for (Node *node = GetHead(); node; node = node->GetNext())
	node->Dump(true);
    puts("}");
}


    //  List of Aliases

AliasNode::AliasNode(const char *name, const char *alias)
    : Node(name), Alias(NULL)
{
    if (alias) {
	Alias = new char[strlen(name)+1];
	strcpy(Alias, name);
    }
}

void AliasNode::Dump(bool in_list) const
{
    printf("%s\"%s\" ", in_list ? "    " : "alias ", Name ? Name : "UNNAMED");
    printf("%s\n", Alias);
}

AliasList::AliasList()
    : List("aliases")
{}

AliasList Aliases;

