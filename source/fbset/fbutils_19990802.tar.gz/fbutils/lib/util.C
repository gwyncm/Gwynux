
#include <errno.h>
#include <fcntl.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/ioctl.h>

#include "util.h"


const char *ProgramName;


    //  Print an Error Message and Exit

void Die(const char *fmt,...)
{
    va_list ap;

    fflush(stdout);
    va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);

    exit(1);
}


    //  Print a Warning Message

void Warn(const char *fmt,...)
{
    va_list ap;

    fflush(stdout);
    va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);
}


    //  Command Line Parameter Processing

int GetNextOption(int &argc, const char **&argv,
		  const struct option options[], const u_int num_options)
{
    static bool first = true;
    static u_int incr_arg = 1;
    static bool default_only = false;
    const struct option *option = NULL;

    if (first) {
	ProgramName = argv[0];
	first = false;
    }
    do {
	argc -= incr_arg;
	argv += incr_arg;
	incr_arg = 0;
	if (!argc)
	    return 0;

	if (default_only || argv[0][0] != '-')
	    return -1;

	if (argv[0][1] != '-') {
	    if (argv[0][1] != '\0' && argv[0][2] == '\0')
		for (u_int i = 0; i < num_options; i++)
		    if (argv[0][1] == options[i].short_key) {
			option = &options[i];
			break;
		    }
	} else if (argv[0][2] == '\0') {
	    default_only = true;
	    incr_arg = 1;
	    continue;
	} else
	    for (u_int i = 0; i < num_options; i++)
		if (!strcmp(&argv[0][2], options[i].long_key)) {
		    option = &options[i];
		    break;
		}

	if (!option)
	    Die("Unknown option %s\nUse `%s --help' for help\n", argv[0],
		ProgramName);

	incr_arg = 1+option->num_args;
	if (!option->store_args)
	    return option->id;
	if (option->num_args == 0) {
	    bool *p = (bool *)option->store_args;
	    *p = !*p;
	} else {
	    const char **p = (const char **)option->store_args;
	    for (u_int i = 0; i < option->num_args; i++)
		p[i] = argv[1+i];
	}

    } while (1);
}
