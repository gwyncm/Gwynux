
#include <string.h>

#include "database.h"
#include "util.h"


    //  List of Screen Geometries

Geometry::Geometry(const VarScreenInfo &var)
    : xres(var.xres), yres(var.yres), pixclock(var.pixclock),
      left_margin(var.left_margin), right_margin(var.right_margin),
      upper_margin(var.upper_margin), lower_margin(var.lower_margin),
      hsync_len(var.hsync_len), vsync_len(var.vsync_len), vmode(var.vmode),
      sync(var.sync)
{}

void Geometry::Print(const char *indent) const
{
    printf("%sxres = %d\n", indent, xres);
    printf("%syres = %d\n", indent, yres);
    printf("%spixclock = %f kHz\n", indent, pixclock ? 1E9/pixclock : 0);
    printf("%sleft_margin = %d\n", indent, left_margin);
    printf("%sright_margin = %d\n", indent, right_margin);
    printf("%supper_margin = %d\n", indent, upper_margin);
    printf("%slower_margin = %d\n", indent, lower_margin);
    printf("%shsync_len = %d\n", indent, hsync_len);
    printf("%svsync_len = %d\n", indent, vsync_len);
    printf("%svmode = %d\n", indent, vmode);
    printf("%ssync = %d\n", indent, sync);
}

void Geometry::XFree86(const char *indent) const
{
#warning Not yet implemented
}

void Geometry::Dump(bool in_list) const
{
    printf("{ %d %d %d %d %d %d %d %d %d ", xres, yres, pixclock,
	   left_margin, right_margin, upper_margin, lower_margin, hsync_len,
	   vsync_len);
    // if (vmode) ...
    if (IsInterlaced())
	printf("interlace ");
    if (IsDoubleScan())
	printf("doublescan ");
    // if (sync) ...
    puts("}");
}

void GeometryNode::Dump(bool in_list) const
{
    printf("%s\"%s\" ", in_list ? "    " : "geometry ",
	   Name ? Name : "UNNAMED");
    Geometry::Dump();
}

GeometryList::GeometryList()
    : List("geometry")
{}

GeometryList Geometries;


    //  List of Pixel Formats

Format::Format(const VarScreenInfo &var)
    : bits_per_pixel(var.bits_per_pixel), grayscale(var.grayscale),
      red(var.red), green(var.green), blue(var.blue), transp(var.transp),
      nonstd(var.nonstd)
{}

void Format::Print(const char *indent) const
{
    printf("%sbits_per_pixel = %d\n", indent, bits_per_pixel);
    printf("%sgrayscale = %d\n", indent, grayscale);
    printf("%sred = %d:%d:%d\n", indent, red.offset, red.length,
	   red.msb_right);
    printf("%sgreen = %d:%d:%d\n", indent, green.offset, green.length,
	   green.msb_right);
    printf("%sblue = %d:%d:%d\n", indent, blue.offset, blue.length,
	   blue.msb_right);
    printf("%stransp = %d:%d:%d\n", indent, transp.offset, transp.length,
	   transp.msb_right);
    printf("%snonstd = %d\n", indent, nonstd);
}

void Format::Dump(bool in_list) const
{
    printf("{ %d %d:%d:%d %d:%d:%d %d:%d:%d %d:%d:%d %d %d }\n",
           bits_per_pixel, red.offset, red.length, red.msb_right, green.offset,
	   green.length, green.msb_right, blue.offset, blue.length,
	   blue.msb_right, transp.offset, transp.length, transp.msb_right,
	   grayscale, nonstd);
}

void FormatNode::Dump(bool in_list) const
{
    printf("%s\"%s\" ", in_list ? "    " : "format ", Name ? Name : "UNNAMED");
    Format::Dump();
}

FormatList::FormatList()
    : List("format")
{}

FormatList Formats;


    //  Virtual Screen Dimensions

Virtual::Virtual(const VarScreenInfo &var)
    : xres_virtual(var.xres_virtual), yres_virtual(var.yres_virtual)
{}

void Virtual::Print(const char *indent) const
{
    printf("%sxres_virtual = %d\n", indent, xres_virtual);
    printf("%syres_virtual = %d\n", indent, yres_virtual);
}

void Virtual::Dump(void) const
{
    printf("virtual %d %d\n", xres_virtual, yres_virtual);
}


    //  List of Video Modes

Videomode::Videomode(const char *name, const Geometry &geometry,
		     const Format &format, const Virtual *virtual_)
    : Node(name), Geometry(geometry), Format(format), PixelRate(0.0),
      HorizSync(0), VertSync(0)
{
    if (virtual_)
	*((Virtual *)this) = *virtual_;
    else {
	xres_virtual = xres;
	yres_virtual = yres;
    }
    FillScanRates();
}

Videomode::Videomode(const VarScreenInfo &var)
    : Geometry(var), Format(var), Virtual(var), PixelRate(0.0), HorizSync(0),
      VertSync(0)
{
    accel_flags = var.accel_flags;
    FillScanRates();
}

void Videomode::FillScanRates(void)
{
    u_int htotal = left_margin+xres+right_margin+hsync_len;
    u_int vtotal = upper_margin+yres+lower_margin+vsync_len;

    if (IsDoubleScan())
	vtotal <<= 2;
    else if (!IsInterlaced())
	vtotal <<= 1;

    if (htotal == 0 || vtotal == 0)
	if (Name)
	    Die("Illegal video mode `%s'\n", Name);
	else
	    Die("Illegal video mode\n");

    if (pixclock != 0) {
	PixelRate = 1E12/pixclock;
	HorizSync = PixelRate/htotal;
	VertSync = HorizSync/vtotal*2;
    }
}

void Videomode::Print(const char *indent) const
{
    char *indent2 = new char[strlen(indent)+5];
    strcpy(indent2, "    ");
    strcat(indent2, indent);

    printf("%sScreen geometry:\n", indent);
    ((Geometry *)this)->Print(indent2);
    printf("%sPixel format:\n", indent);
    ((Format *)this)->Print(indent2);
    printf("%sVirtual screen dimensions:\n", indent);
    ((Virtual *)this)->Print(indent2);
}

void Videomode::Dump(bool in_list) const
{
    printf("%s\"%s\" {\n", in_list ? "    " : "mode ",
	   Name ? Name : "UNNAMED");
    printf(in_list ? "\t" : "    ");
    Geometry::Dump();
    printf(in_list ? "\t" : "    ");
    Format::Dump();
    printf(in_list ? "\t" : "    ");
    Virtual::Dump();
    printf("%s}\n", in_list ? "    " : "");
}

VideomodeList::VideomodeList()
    : List("mode")
{}

VideomodeList Videomodes;


void DumpDatabase(void)
{
    puts("\n# Screen Geometry Definitions\n");
    Geometries.Dump();
    puts("\n# Pixel Format Definitions\n");
    Formats.Dump();
    puts("\n# Video Mode Definitions\n");
    Videomodes.Dump();
    puts("\n# Alias Definitions\n");
    Aliases.Dump();
    putchar('\n');
}

