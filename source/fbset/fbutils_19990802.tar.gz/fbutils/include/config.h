
#define VERSION		"Linux Frame Buffer Device Configuration " \
			"Version 3.0 (12/07/1999)\n"  \
			"(C) Copyright 1995-1999 by Geert Uytterhoeven " \
			"<geert@linux-m68k.org>\n"


    //  Default Frame Buffer Special Device Node

#define DEFAULT_FRAMEBUFFER	"/dev/fb0"


    //	Default Video Mode Database File

#define DEFAULT_MODEDBFILE	"/etc/fb/modes"

