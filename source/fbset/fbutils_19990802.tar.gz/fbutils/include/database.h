
#ifndef __DATABASE_H
#define __DATABASE_H

#include "framebuffer.h"
#include "list.h"


    //  List of Screen Geometries

class Geometry {
    public:
	Geometry();
	Geometry(const VarScreenInfo &var);
	virtual ~Geometry() {}
	void Clear(void);
	void Print(const char *indent = "") const;
	void XFree86(const char *indent = "") const;
	virtual void Dump(bool in_list = false) const;
	bool IsInterlaced(void) const;
	bool IsDoubleScan(void) const;

	__u32 xres;
	__u32 yres;
	__u32 pixclock;
	__u32 left_margin;
	__u32 right_margin;
	__u32 upper_margin;
	__u32 lower_margin;
	__u32 hsync_len;
	__u32 vsync_len;
	__u32 vmode;
	__u32 sync;
};

class GeometryNode : public Node,
		     public Geometry {
    public:
	GeometryNode(const char *name, const Geometry &geometry);
	virtual void Dump(bool in_list = false) const;
};

class GeometryList : public List {
    public:
	GeometryList();
	GeometryNode *Find(const char *name) const;
};


    //  List of Pixel Formats

class Format {
    public:
	Format();
	Format(const VarScreenInfo &var);
	virtual ~Format() {}
	void Clear(void);
	void Print(const char *indent = "") const;
	virtual void Dump(bool in_list = false) const;

	__u32 bits_per_pixel;
	__u32 grayscale;
	struct fb_bitfield red;
	struct fb_bitfield green;
	struct fb_bitfield blue;
	struct fb_bitfield transp;
	__u32 nonstd;
};

class FormatNode : public Node,
		   public Format {
    public:
	FormatNode(const char *name, const Format &format);
	virtual void Dump(bool in_list = false) const;
};

class FormatList : public List {
    public:
	FormatList();
	FormatNode *Find(const char *name) const;
};


    //  Virtual Screen Dimensions

class Virtual {
    public:
	Virtual();
	Virtual(const VarScreenInfo &var);
	void Clear(void);
	void Print(const char *indent = "") const;
	void Dump(void) const;

	__u32 xres_virtual;
	__u32 yres_virtual;
};


    //  List of Video Modes

class Videomode : public Node,
		  public Geometry,
		  public Format,
		  public Virtual {
    public:
	Videomode(const char *name, const Geometry &geometry,
		  const Format &format, const Virtual *_virtual = NULL);
	Videomode(const VarScreenInfo &var);
	void Print(const char *indent = "") const;
	void Dump(bool in_list = false) const;

    private:
	void FillScanRates(void);

    public:
	__u32 accel_flags;

    private:
	double PixelRate;
	double HorizSync;
	double VertSync;
};

class VideomodeList : public List {
    public:
	VideomodeList();
	Videomode *Find(const char *name) const;
};


    //  Inline functions

inline Geometry::Geometry()
{
    Clear();
}

inline void Geometry::Clear(void)
{
    memset(this, 0, sizeof(*this));
}

inline bool Geometry::IsInterlaced(void) const
{
    return (vmode & FB_VMODE_MASK) == FB_VMODE_INTERLACED;
}

inline bool Geometry::IsDoubleScan(void) const
{
    return (vmode & FB_VMODE_MASK) == FB_VMODE_DOUBLE;
}

inline GeometryNode::GeometryNode(const char *name,
				  const Geometry &geometry)
    : Node(name), Geometry(geometry)
{}

inline GeometryNode *GeometryList::Find(const char *name) const
{
    return (GeometryNode *)List::Find(name);
}

inline Format::Format()
{
    Clear();
}

inline void Format::Clear(void)
{
    memset(this, 0, sizeof(*this));
}

inline FormatNode::FormatNode(const char *name, const Format &format)
    : Node(name), Format(format)
{}

inline FormatNode *FormatList::Find(const char *name) const
{
    return (FormatNode *)List::Find(name);
}

inline Virtual::Virtual()
{
    Clear();
}

inline void Virtual::Clear(void)
{
    memset(this, 0, sizeof(*this));
}

inline Videomode *VideomodeList::Find(const char *name) const
{
    return (Videomode *)List::Find(name);
}

    //  Database

extern GeometryList Geometries;
extern FormatList Formats;
extern VideomodeList Videomodes;

extern void DumpDatabase(void);
extern void ReadDatabase(const char *filename);

#endif	// __DATABASE_H

